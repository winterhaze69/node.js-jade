var express = require('express');
var router = express.Router();

router.get('/:id', function(req, res, next) {
  res.render('todo', {'id': req.params.id});
  //res.send(req.params.id);
});

module.exports = router;
