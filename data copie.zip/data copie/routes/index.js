var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'TodoList' });
});

router.get('/list', function(req, res, next) {
  res.render('list', { title: 'TodoList' });
});

router.post('/form', (req, res) => { //permet d'envoyer un formulaire
  res.render('form', {
    title: 'Tasks',
    inputTitle: req.body.title,
    inputTitle2: req.body.title2,
    inputTitle3: req.body.title3,
  });
     //res.send(req.body);
})

module.exports = router;
